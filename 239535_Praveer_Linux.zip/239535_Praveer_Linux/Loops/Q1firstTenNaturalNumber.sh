#!/bin/bash
echo "First 10 Natural number "
for i in {1..10}
do
	echo "$i"
done
